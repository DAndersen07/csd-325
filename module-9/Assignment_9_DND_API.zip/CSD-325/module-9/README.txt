Dustin Andersen - CSD-325 Assignment 9

Open a terminal in CSD-325/module-9 and run:
  py -m pip install -r requirements.txt
  py connection_test.py
  py astronauts_api.py
  py dnd_api.py

Use python instead of py if necessary.

Capture screenshots with Windows + Shift + S and paste them into
Assignment_9_API.docx in the indicated sections. The D&D raw response
and formatted JSON must both be visible; take more than one screenshot
if needed. Save the Word document after inserting screenshots.

All three programs returned HTTP 200 during execution. If a request
fails on your computer, keep the actual error and retry later.
Do not use the tutorial's old example names as current astronaut data.

The Word document contains actual captured D&D execution output as text,
not desktop screenshots. It still needs your required screenshots.
