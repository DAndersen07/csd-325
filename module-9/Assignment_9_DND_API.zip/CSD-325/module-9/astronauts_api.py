# Dustin Andersen
# CSD-325 Assignment 9

import json
import requests


def jprint(obj):
    """Display JSON using the tutorial formatting."""
    print(json.dumps(obj, sort_keys=True, indent=4))


def main():
    print("Current astronauts")
    url = "http://api.open-notify.org/astros.json"
    print("URL:", url)
    try:
        response = requests.get(url, timeout=20)
        # Check the connection before processing the response.
        print("HTTP status code:", response.status_code)
        response.raise_for_status()
        print("\nUnformatted response")
        print(response.text)
        data = response.json()
        print("\nFormatted response")
        jprint(data)
        print("\nPeople in space:", data["number"])
        for person in data["people"]:
            print(f"{person['name']} - {person['craft']}")
    except requests.RequestException as error:
        print("Request failed:", error)
        return 1
    except ValueError as error:
        print("The response was not valid JSON:", error)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
