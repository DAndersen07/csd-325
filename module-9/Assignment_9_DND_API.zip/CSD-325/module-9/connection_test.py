# Dustin Andersen
# CSD-325 Assignment 9
import requests

# Use the corrected astronaut endpoint before processing its JSON.
url = "http://api.open-notify.org/astros.json"
try:
    response = requests.get(url, timeout=20)
    print("URL:", url)
    print("HTTP status code:", response.status_code)
    response.raise_for_status()
except requests.RequestException as error:
    print("Connection test failed:", error)
    raise SystemExit(1)
